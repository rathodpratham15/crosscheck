---
name: Decision docs — skeleton only, no speculative prose
description: For decision/approach/retro docs, generate only section headers + empty bullets; never fill in decision rationale speculatively
type: feedback
originSessionId: 59c398f2-0611-4930-9758-50ea7723734c
---
When creating documents meant to capture the user's real decisions (APPROACH.md, design docs, retrospectives, architecture decision records), produce **skeleton only**: section headers, subheaders, and empty bullet placeholders. Do not write filled-in decision text, rationale, or tradeoff prose — leave bullets empty for the user to populate as actual decisions are made.

**Why:** During the Luma take-home (2026-05-12) Pratham rejected an APPROACH.md I'd filled with reasoned prose. He pointed out the file is meant to capture *his* real decisions during the build — not my upfront speculation. Filled-in prose is AI-generated content masquerading as the user's judgment, which defeats the purpose.

**How to apply:** For any document framed as "decisions / approach / tradeoffs / what I built and why," default to a skeleton. Headers and empty bullets are fine; `_TBD_` placeholders for URLs and metadata are fine. Do NOT write "I chose X over Y because Z" sentences unless the user has already articulated that decision verbatim. The user fills substance as they go.
