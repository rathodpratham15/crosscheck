---
name: No Co-Authored-By trailer in commits
description: For this user's repos, do not append Co-Authored-By trailers to git commits
type: feedback
originSessionId: 59c398f2-0611-4930-9758-50ea7723734c
---
Do **not** add `Co-Authored-By: Claude` (or other AI co-author trailers) to commit messages for Pratham's repos. Write commit messages as if Pratham authored them solo.

**Why:** During the Luma take-home (2026-05-12) Pratham asked me to strip the trailer I'd added by default. AI use is already documented through the take-home's required AI session history packaging; adding a co-author trailer also clutters the commit log without adding signal. He prefers clean commits.

**How to apply:** Skip the trailer on every commit by default. Override only if the user explicitly asks for it.
