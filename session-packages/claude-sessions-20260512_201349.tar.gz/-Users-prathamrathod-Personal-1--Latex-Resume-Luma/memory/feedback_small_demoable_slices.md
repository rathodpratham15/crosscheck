---
name: Prefer small slices with demoable end states
description: Default to 15–45 minute work slices that each end in a concretely demoable state; split anything longer up front
type: feedback
originSessionId: 59c398f2-0611-4930-9758-50ea7723734c
---
When proposing a unit of work, default to 15–45 minute slices where each ends in a concretely demoable state (curl-testable, browser-visible, etc.). Avoid 1-hour+ slices that bundle multiple concerns. If a feature naturally spans more than ~45 min, propose splitting it into sub-slices before starting, with each sub-slice's demoable end state explicitly stated.

**Why:** Pratham (2026-05-12, Luma take-home) pushed back on a 2–2.5h Slice 2 proposal, asking me to split it into three ~30–45 min pieces. Reasoning: smaller slices give faster feedback loops, reduce risk of being stuck mid-slice with nothing visible, and make it easier to push back on a 30-min spec than a 2-hour one. The split also forces honest interface design between layers since the boundaries become visible.

**How to apply:** Before proposing a slice, estimate its time. If >45 min, propose the breakdown first. When listing acceptance criteria for a slice, explicitly state the "demoable end state" — what the user could show off if forced to stop right there.
