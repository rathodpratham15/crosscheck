---
name: Luma Labs application
description: Pratham is in the take-home stage of Luma Labs early-career SWE interview; this directory holds resume, prep materials, and the take-home build
type: project
originSessionId: 59c398f2-0611-4930-9758-50ea7723734c
---
Pratham is applying to Luma Labs (lumalabs.ai) for an early-career Software Engineer role (base $170k–$290k). Currently in **take-home stage** as of 2026-05-12.

## Directory layout
Workspace: `/Users/prathamrathod/Personal/1. Latex Resume/Luma/`
- `Pratham_Rathod_Resume.pdf` — current tailored resume (latest 2026-05-10)
- `Pratham_Rathod_Resume-1.pdf` — earlier version
- `Luma Ai Early Careers Interview Prep Guide.pdf`
- `Luma_AI_Interview_Prep_QA.pdf`
- `take-home/` — challenge workspace (created 2026-05-12)
  - `lumalabs-eng-take-home-334bb175c55b43ff8cd2b37ae4ca09e1f0c65865/` — extracted challenge (git repo, name: `crosscheck`)

GitHub repo: https://github.com/rathodpratham15/crosscheck (private)
Product name: **crosscheck** — citation-grounded research assistant for AI/ML papers

## Take-home timing
- **Downloaded:** 2026-05-12 10:43:10 EDT
- **Deadline:** 2026-05-19 10:43:10 EDT (7-day window from download)

## Take-home choice
**Option 3: Clone and improve a feature.** Cloning Perplexity's "answer with citations" mode, vertical-specialized for AI/ML research (sources limited to arxiv, Semantic Scholar, Papers with Code, GitHub).

Differentiation angles ("better than Perplexity"):
- Inline citations streaming in real-time (not appearing after the answer)
- Source confidence scores shown
- Side-panel source viewer (not new-tab)
- Vertical-pure sources, no blogspam

## Stack decisions
- Next.js 16.2.6 (App Router) + TypeScript — Pratham's strongest stack
- Anthropic Claude Sonnet streaming + tool use
- Tavily Search API (or Brave) restricted to academic sources
- Tailwind 4 (shadcn/ui deferred — may add later for polish)
- Deploy on Vercel
- Vercel AI SDK for streaming/tool-use ergonomics

## Pratham's experience signals
- Strongest stack: TypeScript / Next.js / Node
- AI APIs: shipped one or two basic projects (completions/chat), not yet comfortable with streaming/tool-use
- Wants the solution to lean into multimodal/AI-native angle to align with Luma's domain

## Deliverables (from README)
1. Working software (must run in fresh Linux container; deploy live URL preferred)
2. APPROACH.md (what built + why, decisions/tradeoffs, what was cut, what breaks first, what's next)
3. ~5-min video walkthrough → link in video.md
4. AI session history (auto-packaged by submit.sh)

Note: Email 1 says "scalable API" is required; README says "working software." README is authoritative but bias toward including a backend service to hedge.

Submission: `./submit.sh` (handles AI session packaging + repo access grant).

**Why:** Pratham is actively interviewing here — this directory is the workspace for resume tailoring AND the take-home build. The clock is ticking.
**How to apply:** When he asks for help in this folder, prioritize the take-home build flow (planning, scoping, coding, deploy, video, submit). For the build, frame suggestions around the JD's signals (AI agent fluency, shipped projects, ownership stories, multimodal/creative-AI alignment). The take-home explicitly grades how he directs AI tools — lean into helping him direct *me* well, surface tradeoffs, push back where appropriate, and document the judgment trail.
