---
name: Propose memory writes before saving
description: Never write a new memory file (or substantively update one) without first proposing it in chat and waiting for explicit user approval
type: feedback
originSessionId: 59c398f2-0611-4930-9758-50ea7723734c
---
Never write a memory file (new or substantively updated) without first proposing it in chat with the exact name, type, and content I plan to save, and asking for explicit user approval. Wait for an explicit "yes" before calling Write. Trivial edits to existing memory entries (typo fixes, factual staleness corrections the user authorized) are exempt; new memories and new feedback patterns are not.

**Why:** Pratham (2026-05-12) directed that he wants visibility into what's being persisted before it lands, since memory shapes my future behavior across sessions. Silent memory writes — even well-intentioned ones — undermine that control. Surfacing the proposal also catches phrasing errors before they bake in.

**How to apply:** When I notice a pattern I'd want to save, output: *"I want to save this pattern: [name + type + full content]. Okay?"* and wait. Do not call Write to MEMORY.md or any memory file until I get an explicit yes.
